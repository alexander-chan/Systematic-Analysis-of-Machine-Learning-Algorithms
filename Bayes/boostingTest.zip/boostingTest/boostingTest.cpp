#include <cv.h>
#include <ml.h>
#include <stdio.h>
#include <unistd.h>

using namespace cv;

#define NUMBER_OF_ATTRIBUTES 10
#define NUMBER_OF_CLASSES 2

enum Code 
{
	FG_RED		= 31,
	FG_GREEN		= 32,
	FG_DEFAULT	= 39,
	FG_YELLOW 	= 35
};
class Modifier 
{
	Code code;
	public:
		Modifier(Code pCode) : code(pCode) {}
		friend std::ostream& operator<<(std::ostream& os, const Modifier& mod) 
		{
            return os << "\033[" << mod.code << "m";
		}
};

int main( int argc, char** argv )
{
	FileStorage fs;
		
	if(!fs.open("data.xml", FileStorage::READ)) {
		printf("Error: Could not locate 'data.xml'\nExiting...\n");
		return -1;
	};

	CvBoost* boostTree = new CvBoost;

	boostTree->load("trainedBoost.xml", "boostTree");
	
	printf ("Using OpenCV version %s\n", CV_VERSION);
	
	Modifier red(FG_RED);
	Modifier green(FG_GREEN);
	Modifier yellow(FG_YELLOW);
	Modifier def(FG_DEFAULT);
	
	clock_t t2,t3;
	
	Mat testingData;
	Mat testingClasses;
	
	fs["testingData"] >> testingData;
	fs["testingClasses"] >> testingClasses;
	
	int testingRows = testingData.rows;

	Mat varType = Mat(NUMBER_OF_ATTRIBUTES + 1, 1, CV_8U );
	varType.setTo(Scalar(CV_VAR_NUMERICAL) );

	varType.at<uchar>(NUMBER_OF_ATTRIBUTES, 0) = CV_VAR_CATEGORICAL;

	double result;

	t2=clock();

	Mat testSample;
	
	int confusion[2][2] = {0,0,0,0};

	for (int tsample = 0; tsample < testingRows; tsample++)
	{

		testSample = testingData.row(tsample);

		result = boostTree->predict(testSample, Mat());
		
		std::cout << yellow << "Sample " << tsample << " -> " << def;

		printf("class prediction is (%d) ", (int)result);
		
		if(result == 1)
		{
			if(testingClasses.at<float>(tsample) == 1) {
				confusion[0][0]++;
				std::cout << green << "[CORRECT]" << def << std::endl;
			}
			else {
				confusion[1][0]++;
				std::cout << red << "[INCORRECT]" << def << std::endl;
			}
		}
		else
		{
			if(testingClasses.at<float>(tsample) != 1) {
				confusion[1][1]++;
				std::cout << green << "[CORRECT]" << def << std::endl;
			}
			else {
				confusion[0][1]++;
				std::cout << red << "[INCORRECT]" << def << std::endl;
			}
		}
		usleep(1000);
	}
	
	std::cout << "\nConfusion Matrix:" << std:: endl;
	
	printf("\t%10d%8d\n", 1, 0);
	printf("\t%1d%9d%8d\n", 1, confusion[0][0], confusion[0][1]);
	printf("\t%1d%9d%8d\n", 0, confusion[1][0], confusion[1][1]);
	
	int correctClass = confusion[0][0] + confusion[1][1];
	int incorrectClass = confusion[0][1] + confusion[1][0];

	printf( "\nTest Results:\n"
	"\tCorrect classifications: %d (%g%%)\n"
	"\tIncorrect classifications: %d (%g%%)\n",
	correctClass, (double) correctClass*100/testingRows,
	incorrectClass, (double) incorrectClass*100/testingRows);

	t3=clock();
	float diff2 ((float)t3-(float)t2);
	float seconds2 = diff2 / CLOCKS_PER_SEC;
	printf("\tTesting: %f sec.\n\n", seconds2);

	return 0;
}